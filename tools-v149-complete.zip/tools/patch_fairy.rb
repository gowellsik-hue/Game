# encoding: UTF-8
require 'zlib'

game = ARGV.fetch(0)
ini_path = File.join(game, 'Game.ini')
ini = File.binread(ini_path)
rel = ini[/^Scripts=(.+)$/i, 1].to_s.strip.tr('\\', '/')
abort 'Fairy Scripts entry missing' if rel.empty?
source_path = File.join(game, rel)
abort "Fairy scripts missing: #{source_path}" unless File.file?(source_path)
scripts = Marshal.load(File.binread(source_path))

def inflate(e)
  Zlib::Inflate.inflate(e[2]).force_encoding(Encoding::UTF_8)
end

def deflate(e, s)
  e[2] = Zlib::Deflate.deflate(s)
end

def entry_for(scripts, name)
  scripts.find { |x| x.is_a?(Array) && x.length >= 3 && x[1].to_s == name }
end

compat = <<'RUBY'
$joiplay=true
module Kernel
  def exit(*args); nil; end
end
class Win32API
  def initialize(*args); @func=args[1].to_s; end
  def web_input(key)
    case key.to_i
    when 9,90 then Input::A
    when 13,32,67 then Input::C
    when 27,88 then Input::B
    when 68 then Input::Z
    when 81 then Input::L
    when 83 then Input::Y
    when 87 then Input::R
    when 65 then Input::X
    when 16 then Input::SHIFT
    when 17 then Input::CTRL
    when 18 then Input::ALT
    else nil
    end
  end
  def call(*args)
    code=web_input(args[0])
    return(code && Input.trigger?(code) ? 1 : 0) if @func=='GetAsyncKeyState'
    return(code && Input.press?(code) ? -1 : 0) if @func=='GetKeyState'
    0
  end
  def Call(*args); call(*args); end
end
Font.default_name='NanumGothic'
module Audio
  def self.sl_stream(kind,*parts); puts((['SLAUDIO',kind]+parts.collect{|v|v.to_s}).join('|')); end
  def self.bgm_play(filename,volume=100,pitch=100); sl_stream('BGM_PLAY',filename,volume,pitch); end
  def self.bgm_stop; sl_stream('BGM_STOP'); end
  def self.bgm_fade(time); sl_stream('BGM_FADE',time); end
  def self.bgs_play(filename,volume=100,pitch=100); sl_stream('BGS_PLAY',filename,volume,pitch); end
  def self.bgs_stop; sl_stream('BGS_STOP'); end
  def self.bgs_fade(time); sl_stream('BGS_FADE',time); end
end
RUBY

# Remove old copies if the workflow is rerun against already-patched content.
scripts.reject! { |e| e.is_a?(Array) && e.length >= 3 && ['Web Compatibility','Mobile Diablo Assist'].include?(e[1].to_s) }
scripts.insert(0, [0, 'Web Compatibility', Zlib::Deflate.deflate(compat)])

def patch_begin_until(src)
  lines=src.lines
  lines.each_index do |i|
    m=lines[i].match(/^(\s*)end\s+until\s+(.+?)\s*$/)
    next unless m
    indent,cond=m[1],m[2]
    j=i-1
    while j>=0
      if lines[j][/^\s*/]==indent && lines[j].strip=='begin'
        lines[j]=indent+"loop do\n"
        lines[i]=indent+"  break if #{cond}\n#{indent}end\n"
        break
      end
      j-=1
    end
  end
  lines.join
end

def patch_scene_loop(src)
  lines=src.lines
  i=0
  while i<lines.length
    unless lines[i].strip=='loop do'
      i+=1
      next
    end
    indent=lines[i][/^\s*/]
    sig=[]
    k=i+1
    while k<lines.length && sig.length<8
      s=lines[k].strip
      sig << [k,s,lines[k][/^\s*/]] unless s.empty? || s.start_with?('#')
      k+=1
    end
    finish=nil
    if sig.length>=7 && sig[0][1]=='Graphics.update' && sig[1][1]=='Input.update' && sig[2][1]=='update' && sig[3][1]=='if $scene != self' && sig[4][1]=='break' && sig[5][1]=='end' && sig[6][1]=='end' && sig[6][2]==indent
      finish=sig[6][0]
    elsif sig.length>=5 && sig[0][1]=='Graphics.update' && sig[1][1]=='Input.update' && sig[2][1]=='update' && sig[3][1]=='break if $scene != self' && sig[4][1]=='end' && sig[4][2]==indent
      finish=sig[4][0]
    end
    if finish
      lines[i..finish]=[indent+"end\n\n"+indent+"def dispose\n"]
    end
    i+=1
  end
  lines.join
end

browser_loop = <<'RUBY'
$prev_scene=nil
$sl_last_scene_name=nil
def main_update_loop
  begin
    if $scene!=nil
      active_scene=$scene
      name=active_scene.class.to_s
      if $sl_last_scene_name!=name
        puts('SLFRAME|'+name)
        $sl_last_scene_name=name
      end
      if active_scene!=$prev_scene
        $prev_scene.dispose if $prev_scene!=nil && $prev_scene.respond_to?(:dispose)
        active_scene.main
        $prev_scene=active_scene
        return if $scene!=active_scene
      end
      Graphics.update
      Input.update
      active_scene.update if $scene==active_scene
    end
  rescue Exception=>e
    puts('SLRUNTIMEERR|'+e.class.to_s+'|'+e.message.to_s)
    e.backtrace[0,16].each{|line| puts('SLRUNTIMEBT|'+line.to_s)} if e.respond_to?(:backtrace) && e.backtrace
  end
end
RUBY

font_rules=[
  [/((?:Font\.default_name)\s*=\s*)\[\s*["'][^"']*["']\s*\]/n,'\\1"NanumGothic"'],
  [/(Font\.default_name\s*=\s*)["'][^"']*["']/n,'\\1"NanumGothic"'],
  [/(\.font\.name\s*=\s*)["'][^"']*["']/n,'\\1"NanumGothic"'],
  [/(\bFONT_NAME\s*=\s*)["'][^"']*["']/n,'\\1"NanumGothic"']
]

plane_count=0
scripts.each do |entry|
  next unless entry.is_a?(Array) && entry.length>=3
  name=entry[1].to_s
  begin
    text=inflate(entry)
  rescue
    next
  end
  font_rules.each{|rx,rep| text.gsub!(rx,rep)}
  text.gsub!('defined?($joiplay) && $joiplay','$joiplay == true')
  if text.match?(/^\s*class\s+Plane\s*<\s*Sprite\b/n)
    text="# native Plane used on web\n"
    plane_count+=1
  end
  text=patch_begin_until(text)
  text=patch_scene_loop(text) unless name=='Main' || name=='Scene_Map'
  if name=='Main'
    text=browser_loop+text unless text.include?('def main_update_loop')
    text.sub!(/\n\s*while\s+\$scene\s*!=\s*nil\s*\r?\n\s*\$scene\.main\s*\r?\n\s*end\s*/m,"\n")
  end
  deflate(entry,text)
end
puts "FAIRY_PLANE_PATCH=#{plane_count}"

# Resolution: prefer the game's own resolution script when present, then add a final safety shim.
res = entry_for(scripts,'해상도')
if res
  t=inflate(res)
  t.gsub!('$WINDOW_WIDTH = 640','$WINDOW_WIDTH = 800')
  t.gsub!('$WINDOW_HEIGHT = 480','$WINDOW_HEIGHT = 600')
  t.gsub!('640, 480','800, 600')
  deflate(res,t)
end

# Map input fixes. Direct RGSS inputs are used by the mobile UI to avoid Win32 key collisions.
map=entry_for(scripts,'Scene_Map')
if map
  t=inflate(map)
  unless t.include?('SLFAIRY_MAP_UNLOCK')
    t.sub!(/  def main\r?\n/, "  def main\n    $game_switches[49] = false if $game_switches\n    puts('SLFAIRY_MAP_UNLOCK')\n")
  end
  t.gsub!(/\s*if \$game_switches\[49\] == false\r?\n\s*Input\.update\s*\r?\n\s*end\r?\n/, "     Input.update\n")
  t.gsub!('if Keyboard.testkey(9) &&', 'if (Keyboard.testkey(9) || Input.trigger?(Input::Y)) &&')
  t.gsub!('&& Keyboard.testkey(69) &&', '&& (Keyboard.testkey(69) || Input.trigger?(Input::X)) &&')
  deflate(map,t)
end

# Equipment screen must never leave switch 49 latched on.
equip=entry_for(scripts,'Scene_Equip')
if equip
  t=inflate(equip)
  t.gsub!('$game_switches[49] = true','$game_switches[49] = false')
  deflate(equip,t)
end

# Browser persistence for saves, and return straight to the map.
save=entry_for(scripts,'Scene_Save')
if save
  t=inflate(save)
  unless t.include?('save_file_async(filename)')
    t.sub!(/    write_save_data\(file\)\r?\n    exit/, "    write_save_data(file)\n    file.close\n    save_file_async(filename)")
  end
  unless t.include?('SLFAIRY_SAVE_UNLOCK')
    t.sub!('    save_file_async(filename)', "    save_file_async(filename)\n    $game_switches[49] = false if $game_switches\n    puts('SLFAIRY_SAVE_UNLOCK')")
  end
  t.gsub!('$scene = Scene_Menu.new(4)','$scene = Scene_Map.new')
  if t.match?(/  def on_cancel\r?\n/) && !t.match?(/  def on_cancel\r?\n\s*\$game_switches\[49\] = false/)
    t.sub!(/  def on_cancel\r?\n/, "  def on_cancel\n    $game_switches[49] = false if $game_switches\n")
  end
  deflate(save,t)
end

# Old menu transparency creates a second map spriteset lifecycle and is unsafe in the browser loop.
scripts.each do |e|
  next unless e.is_a?(Array) && e.length>=3
  begin
    t=inflate(e)
  rescue
    next
  end
  if t.include?('XRXS_MP7_Module')
    deflate(e,"# web: XRXS menu transparency disabled\n")
  end
end

# Multi-slot cleanup if this variant contains the same extension.
ms=entry_for(scripts,'Multi-slot script : Windows')
if ms
  t=inflate(ms)
  old=/ alias g7_ms_scene_equip_main main\r?\n def main\r?\n  @additional_initialize_done = false\r?\n  g7_ms_scene_equip_main\r?\n  for i in 5\.\.\.@item_windows\.size\r?\n   @item_windows\[i\]\.dispose unless @item_windows\[i\]\.nil\?\r?\n  end\r?\n end/
  if t.match?(old)
    t.sub!(old," alias g7_ms_scene_equip_main main\n def main\n  @additional_initialize_done = false\n  g7_ms_scene_equip_main\n end\n alias g7_ms_scene_equip_dispose dispose\n def dispose\n  if @item_windows != nil\n   for i in 5...@item_windows.size\n    @item_windows[i].dispose unless @item_windows[i].nil?\n   end\n  end\n  g7_ms_scene_equip_dispose\n end")
  end
  t.gsub!('if defined? xrxs_additional_refresh','if respond_to?(:xrxs_additional_refresh)')
  deflate(ms,t)
end

# HUD viewport follows 800x600 when the MOG HUD extension exists.
scripts.each do |e|
  next unless e.is_a?(Array) && e.length>=3
  begin
    t=inflate(e)
  rescue
    next
  end
  next unless t.include?('alias shud_main main')
  t.gsub!('Viewport.new(0, 0, 640, 480)','Viewport.new(0, 0, $WINDOW_WIDTH, $WINDOW_HEIGHT)')
  deflate(e,t)
end

# Remove historical site/author branding without touching game logic.
scripts.each do |e|
  next unless e.is_a?(Array) && e.length>=3
  begin
    t=inflate(e)
  rescue
    next
  end
  bad=t.downcase.include?('ihsoft') || t.include?('oilhwan') || t.include?('일환소프트') || t.downcase.include?('single lineage') || t.downcase.include?('duenter@hanmail.net')
  next unless bad
  t=t.lines.reject do |ln|
    d=ln.downcase
    d.include?('ihsoft') || ln.include?('oilhwan') || ln.include?('일환소프트') || d.include?('single lineage') || d.include?('duenter@hanmail.net')
  end.join
  deflate(e,t)
end

# Empty-by-default quick slots for Fairy. They are configured from the in-game slot screen.
assist = <<'RUBY'
$mobile_auto_attack_active=false
$mobile_auto_attack_event_id=0
$mobile_auto_attack_cooldown=0

class Game_Event
  def sl_mobile_enemy_event?
    event_data=instance_variable_get(:@event)
    page_data=instance_variable_get(:@page)
    erased=instance_variable_get(:@erased)
    return false if event_data==nil || page_data==nil || erased
    name=event_data.instance_variable_get(:@name).to_s
    return false unless name[0,3]=='[ID'
    return false if self.through
    return false unless self.trigger==2
    true
  end
end

class Interpreter
  alias sl_mobile_original_command_111 command_111
  def command_111
    if $mobile_auto_attack_active && @event_id==$mobile_auto_attack_event_id && @parameters[0]==11 && @parameters[1]==13
      $mobile_auto_attack_active=false
      @branch[@list[@index].indent]=true
      @branch.delete(@list[@index].indent)
      return true
    end
    sl_mobile_original_command_111
  end
end

class Game_System
  def sl_quick_items
    @sl_quick_items=[0,0,0,0] if @sl_quick_items==nil
    @sl_quick_items
  end
  def sl_quick_items=(v); @sl_quick_items=v; end
end

module SLMobileQuick
  def self.emit_labels
    $game_system.sl_quick_items.each_with_index do |id,i|
      item=(id.to_i>0 && $data_items) ? $data_items[id.to_i] : nil
      name=item ? item.name.to_s.gsub('|','/') : '비어있음'
      puts('SLQS|'+(i+1).to_s+'|'+name)
    end
  end
  def self.use(slot)
    return if $game_party==nil || $game_system==nil
    id=$game_system.sl_quick_items[slot].to_i
    item=(id>0 && $data_items) ? $data_items[id] : nil
    unless item && item.is_a?(RPG::Item) && $game_party.item_number(id)>0 && $game_party.item_can_use?(id)
      $game_system.se_play($data_system.buzzer_se) if $data_system
      return
    end
    used=false
    if item.scope>=3
      if item.scope==4 || item.scope==6
        for actor in $game_party.actors
          used |= actor.item_effect(item)
        end
      else
        actor=$game_party.actors[0]
        used=actor ? actor.item_effect(item) : false
      end
    elsif item.common_event_id>0
      used=true
    end
    if used
      $game_system.se_play(item.menu_se)
      $game_party.lose_item(id,1) if item.consumable
      $game_temp.common_event_id=item.common_event_id if item.common_event_id>0
      $KeyIcon.ShowIcon if defined?($KeyIcon) && $KeyIcon
      Guage.show if defined?(Guage)
    else
      $game_system.se_play($data_system.buzzer_se)
    end
  end
end

class Scene_MobileQuick
  def initialize(slot_index=0); @slot_index=slot_index; end
  def main
    @help_window=Window_Help.new
    @help_window.set_text('빠른슬롯을 선택한 뒤 소지 아이템을 지정하세요.')
    build_slot_window
    @item_window=Window_Item.new
    @item_window.help_window=@help_window
    @item_window.active=false
    @item_window.visible=false
    Graphics.transition
  end
  def build_slot_window
    old_index=@slot_window ? @slot_window.index : @slot_index
    @slot_window.dispose if @slot_window
    names=[]
    $game_system.sl_quick_items.each_with_index do |id,i|
      item=(id.to_i>0 && $data_items) ? $data_items[id.to_i] : nil
      names << "#{i+1}. #{item ? item.name.to_s : '비어 있음'}"
    end
    @slot_window=Window_Command.new(300,names)
    @slot_window.x=0
    @slot_window.y=64
    @slot_window.index=[[old_index,0].max,3].min
  end
  def dispose
    Graphics.freeze
    @help_window.dispose if @help_window
    @slot_window.dispose if @slot_window
    @item_window.dispose if @item_window
  end
  def update
    @help_window.update
    @slot_window.update
    @item_window.update
    if @slot_window.active
      if Input.trigger?(Input::B)
        $game_system.se_play($data_system.cancel_se)
        $scene=Scene_Map.new
        return
      end
      if Input.trigger?(Input::C)
        $game_system.se_play($data_system.decision_se)
        @slot_index=@slot_window.index
        @slot_window.active=false
        @item_window.visible=true
        @item_window.active=true
        @item_window.index=0
        @help_window.set_text('이 슬롯에 넣을 소지 아이템을 선택하세요.')
        return
      end
    else
      if Input.trigger?(Input::B)
        $game_system.se_play($data_system.cancel_se)
        @item_window.active=false
        @item_window.visible=false
        @slot_window.active=true
        @help_window.set_text('빠른슬롯을 선택한 뒤 소지 아이템을 지정하세요.')
        return
      end
      if Input.trigger?(Input::C)
        item=@item_window.item
        unless item && item.is_a?(RPG::Item)
          $game_system.se_play($data_system.buzzer_se)
          return
        end
        $game_system.sl_quick_items[@slot_index]=item.id
        $game_system.se_play($data_system.decision_se)
        @item_window.active=false
        @item_window.visible=false
        build_slot_window
        @slot_window.active=true
        @help_window.set_text('지정 완료. 다른 슬롯도 설정할 수 있습니다.')
        return
      end
    end
  end
end

class Game_Player
  alias sl_mobile_original_update update
  def update
    sl_mobile_original_update
    $mobile_auto_attack_cooldown-=1 if $mobile_auto_attack_cooldown>0
    $mobile_auto_attack_active=false if $mobile_auto_attack_active && $mobile_auto_attack_cooldown<=8
    return if moving? || @move_route_forcing || $game_temp.message_window_showing || $game_system.map_interpreter.running? || $mobile_auto_attack_cooldown>0
    return if $game_switches[743]
    target=nil
    for event in $game_map.events.values
      next unless event.sl_mobile_enemy_event?
      if (event.x-self.x).abs+(event.y-self.y).abs==1
        target=event
        break
      end
    end
    return if target==nil
    dx=target.x-self.x; dy=target.y-self.y
    if dx>0; turn_right
    elsif dx<0; turn_left
    elsif dy>0; turn_down
    else; turn_up
    end
    target.turn_toward_player
    $mobile_auto_attack_event_id=target.id
    $mobile_auto_attack_active=true
    $mobile_auto_attack_cooldown=20
    target.start
  end
end

class Scene_Map
  alias sl_mobile_quick_main main
  def main
    SLMobileQuick.emit_labels
    sl_mobile_quick_main
  end
  alias sl_mobile_quick_update update
  def update
    if Input.trigger?(Input::F5)
      $scene=Scene_MobileQuick.new
      return
    end
    SLMobileQuick.use(0) if Input.trigger?(Input::F6)
    SLMobileQuick.use(1) if Input.trigger?(Input::F7)
    SLMobileQuick.use(2) if Input.trigger?(Input::F8)
    SLMobileQuick.use(3) if Input.trigger?(Input::F9)
    sl_mobile_quick_update
  end
end
RUBY

scripts.reject!{|e| e.is_a?(Array) && e.length>=2 && e[1].to_s=='Boot Diagnostic'}
main_index=scripts.index{|e| e.is_a?(Array) && e.length>=3 && e[1].to_s=='Main'}
abort 'Fairy Main script missing' unless main_index

# Final web resolution shim just before Main. Safe even if the original resolution script differs.
shim = <<'RUBY'
$WINDOW_WIDTH = 800
$WINDOW_HEIGHT = 600
begin
  Graphics.resize_screen(800,600)
rescue
end
RUBY
diag = "puts 'SLBOOT|RGSS SCRIPT'\n"
scripts.insert(main_index,[99999989,'Boot Diagnostic',Zlib::Deflate.deflate(diag)])
scripts.insert(main_index+1,[99999990,'Web Resolution 800x600',Zlib::Deflate.deflate(shim)])
scripts.insert(main_index+2,[99999992,'Mobile Diablo Assist',Zlib::Deflate.deflate(assist)])

out_path=File.join(game,'Data','Scripts.rxdata')
File.binwrite(out_path,Marshal.dump(scripts))
File.delete(source_path) if File.expand_path(source_path)!=File.expand_path(out_path) && File.exist?(source_path)
lines=ini.split(/\r?\n/).map do |line|
  if line =~ /^Scripts=/i
    'Scripts=Data\\Scripts.rxdata'
  elsif line =~ /^Title=/i
    'Title=SLFairy'
  else
    line
  end
end
File.binwrite(ini_path,lines.join("\r\n")+"\r\n")
puts "FAIRY_SCRIPT_PATCH_OK scripts=#{scripts.length}"
