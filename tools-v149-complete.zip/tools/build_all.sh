#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
TOOLS="$ROOT/repo/tools"
OUT="$ROOT/player"

GAME_URL="${GAME_URL:?}"
GAME_SHA256="${GAME_SHA256:?}"
FAIRY_URL="${FAIRY_URL:?}"
FAIRY_SHA256="${FAIRY_SHA256:?}"
FAIRY_7Z_PASSWORD="${FAIRY_7Z_PASSWORD:?}"

for sym in FS_createPath FS_createDataFile addRunDependency removeRunDependency; do
  grep -Fq "$sym" "$ROOT/engine/build/mkxp.js" || {
    echo "MISSING_EMSCRIPTEN_RUNTIME_EXPORT: $sym"
    exit 1
  }
done

prepare_site() {
  local site="$1"
  rm -rf "$site"
  mkdir -p "$site"
  cp -a "$ROOT/engine/build/." "$site/"
  rm -rf "$site/gameasync" "$site/preload"
  mkdir -p "$site/gameasync/Fonts"
  cp "$ROOT/engine/extra/rgss.rb" "$site/gameasync/rgss.rb"
  cp "$ROOT/engine/COPYING" "$site/COPYING-mkxp-web.txt"
  cp /usr/share/fonts/truetype/nanum/NanumGothic.ttf "$site/gameasync/Fonts/NanumGothic.ttf"
  cp /usr/share/fonts/truetype/nanum/NanumGothicBold.ttf "$site/gameasync/Fonts/NanumGothicBold.ttf"
  touch "$site/.nojekyll"
}

build_mapping() {
  local site="$1"
  (
    cd "$site/gameasync"
    bash "$ROOT/engine/extra/make_mapping.sh"
  )
  test -s "$site/gameasync/mapping.js"
  test -s "$site/gameasync/bitmap-map.js"
}

build_preload_package() {
  local site="$1"
  local prefix="$2"
  local game="$site/gameasync"
  local packager="$ROOT/engine/deps/emsdk/upstream/emscripten/tools/file_packager.py"
  source "$ROOT/engine/deps/emsdk/emsdk_env.sh" >/dev/null

  local args=()
  add_path() {
    local src="$1"
    local dst="$2"
    if [ -e "$src" ]; then
      args+=(--preload "$src@$dst")
    else
      echo "PRELOAD_SKIP: $src"
    fi
  }

  add_path "$game/Data" /game/Data
  add_path "$game/Graphics" /game/Graphics
  add_path "$game/Audio/SE" /game/Audio/SE
  add_path "$game/Audio/ME" /game/Audio/ME
  add_path "$game/BM" /game/BM
  add_path "$game/Fonts" /game/Fonts
  add_path "$game/Game.ini" /game/Game.ini
  add_path "$game/Lineage.ini" /game/Lineage.ini
  add_path "$game/rgss.rb" /game/rgss.rb

  python3 "$packager" "$site/$prefix.data" "${args[@]}" \
    --js-output="$site/$prefix.js" --no-node

  python3 - "$site/$prefix.js" "$prefix.data" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
name=sys.argv[2]
s=p.read_text()
old="var REMOTE_PACKAGE_BASE = '%s';" % name
new="var REMOTE_PACKAGE_BASE = '%s?v=v15';" % name
if old not in s:
    raise SystemExit('REMOTE_PACKAGE_BASE marker missing: '+str(p))
p.write_text(s.replace(old,new,1))
PY

  test -s "$site/$prefix.data"
  test -s "$site/$prefix.js"
  rm -f "$site/gameasync/bitmap-map.js"
  du -h "$site/$prefix.data"
}

patch_web_shell() {
  local site="$1"
  local core="$2"
  local ns="$3"
  local title="$4"
  python3 "$TOOLS/patch_drive.py" "$site"
  cp "$TOOLS/mobile-ui.js" "$site/js/dpad.js"
  ruby -EUTF-8:UTF-8 "$TOOLS/patch_browser.rb" "$site/index.html" "$core" "$ns" "$title"
  node --check "$site/js/drive.js"
  node --check "$site/js/dpad.js"
}

verify_site_common() {
  local site="$1"
  local prefix="$2"
  test -s "$site/index.html"
  test -s "$site/mkxp.js"
  test -s "$site/mkxp.wasm"
  test -s "$site/gameasync/Data/Scripts.rxdata"
  test -s "$site/gameasync/mapping.js"
  test -s "$site/$prefix.data"
  test -s "$site/$prefix.js"
  grep -Fq "preRun: [function(){window.restoreLocalFilesBeforeRun();}]," "$site/index.html"
  grep -Fq "$prefix.js?v=v15" "$site/index.html"
  grep -Fq 'width="800" height="600"' "$site/index.html"
  ! grep -Fq "getLazyAsset('gameasync/bitmap-map.js'" "$site/index.html"
  ! grep -Fq 'BOOT DIAG' "$site/index.html"
}

rm -rf "$OUT" /tmp/v15_knight /tmp/v15_fairy_pkg /tmp/v15_fairy_raw /tmp/v15_fairy_game
mkdir -p "$OUT/knight" "$OUT/elf" /tmp/v15_knight /tmp/v15_fairy_pkg /tmp/v15_fairy_raw /tmp/v15_fairy_game

curl -L --fail --retry 3 -o /tmp/v15_knight.zip "$GAME_URL"
echo "$GAME_SHA256  /tmp/v15_knight.zip" | sha256sum -c -
curl -L --fail --retry 3 -o /tmp/v15_fairy_source.zip "$FAIRY_URL"
echo "$FAIRY_SHA256  /tmp/v15_fairy_source.zip" | sha256sum -c -

# ---------------- KNIGHT ----------------
unzip -q /tmp/v15_knight.zip -d /tmp/v15_knight
prepare_site "$OUT/knight"
cp -a /tmp/v15_knight/SLKnight_Android_JoiPlay/. "$OUT/knight/gameasync/"
rm -f "$OUT/knight/gameasync"/Save*.rxdata "$OUT/knight/gameasync/README_Android.txt"

ruby -EUTF-8:UTF-8 -rzlib "$TOOLS/patch_knight_base.rb" "$OUT/knight/gameasync"
ruby -EUTF-8:UTF-8 "$TOOLS/patch_knight_items.rb" "$OUT/knight"
ruby -EUTF-8:UTF-8 "$TOOLS/patch_knight_runtime.rb" "$OUT/knight"

python3 "$TOOLS/convert_media.py" "$OUT/knight"
build_mapping "$OUT/knight"
build_preload_package "$OUT/knight" slknight-core-v149
patch_web_shell "$OUT/knight" slknight-core-v149.js slknight_v14_engine "SLKnight V15"

ruby -EUTF-8:UTF-8 -rzlib "$TOOLS/verify_knight.rb" "$OUT/knight/gameasync/Data/Scripts.rxdata"
ruby -EUTF-8:UTF-8 -rzlib "$TOOLS/verify_syntax.rb" "$OUT/knight/gameasync/Data/Scripts.rxdata"
ruby -EUTF-8:UTF-8 "$TOOLS/verify_knight_items.rb" "$OUT/knight"
verify_site_common "$OUT/knight" slknight-core-v149

# ---------------- FAIRY ----------------
unzip -q /tmp/v15_fairy_source.zip -d /tmp/v15_fairy_pkg
7z x /tmp/v15_fairy_pkg/SLFairy_Win_241226.7z \
  -p"$FAIRY_7Z_PASSWORD" -o/tmp/v15_fairy_raw -y >/tmp/v15_fairy_7z.log

python3 "$TOOLS/rgssad_extract.py" --selftest
python3 "$TOOLS/rgssad_extract.py" /tmp/v15_fairy_raw/Game.rgssad /tmp/v15_fairy_game
cp /tmp/v15_fairy_raw/Game.ini /tmp/v15_fairy_game/Game.ini
if [ -d /tmp/v15_fairy_raw/Audio ]; then
  mkdir -p /tmp/v15_fairy_game/Audio
  cp -a /tmp/v15_fairy_raw/Audio/. /tmp/v15_fairy_game/Audio/
fi

prepare_site "$OUT/elf"
cp -a /tmp/v15_fairy_game/. "$OUT/elf/gameasync/"
rm -f "$OUT/elf/gameasync/Game.rgssad" "$OUT/elf/gameasync"/Save*.rxdata

ruby -EUTF-8:UTF-8 "$TOOLS/patch_fairy.rb" "$OUT/elf/gameasync"

python3 "$TOOLS/convert_media.py" "$OUT/elf"
build_mapping "$OUT/elf"
build_preload_package "$OUT/elf" slfairy-core-v149
patch_web_shell "$OUT/elf" slfairy-core-v149.js slfairy_v1_engine "SLFairy V15"

ruby -EUTF-8:UTF-8 -rzlib "$TOOLS/verify_fairy.rb" "$OUT/elf/gameasync/Data/Scripts.rxdata"
ruby -EUTF-8:UTF-8 -rzlib "$TOOLS/verify_syntax.rb" "$OUT/elf/gameasync/Data/Scripts.rxdata"
verify_site_common "$OUT/elf" slfairy-core-v149

# ---------------- LAUNCHER ----------------
cp "$TOOLS/launcher.html" "$OUT/index.html"
touch "$OUT/.nojekyll"

grep -Fq '기사' "$OUT/index.html"
grep -Fq '요정' "$OUT/index.html"

echo "V15_DUAL_INDEPENDENT_BUILD_OK"
du -sh "$OUT"
