# encoding: UTF-8
require 'zlib'
a=Marshal.load(File.binread(ARGV[0]))
def entry(a,name)
  a.find{|e|e.is_a?(Array)&&e.length>=3&&e[1].to_s.force_encoding(Encoding::UTF_8)==name}
end
def text(e)
  Zlib::Inflate.inflate(e[2]).force_encoding(Encoding::UTF_8)
end
names=a.select{|e|e.is_a?(Array)&&e.length>=3}.map{|e|e[1].to_s.force_encoding(Encoding::UTF_8)}
abort 'Fairy mobile assist missing' unless names.include?('Mobile Diablo Assist')
abort 'Fairy web resolution missing' unless names.include?('Web Resolution 800x600')

equip=entry(a,'Scene_Equip') or abort 'Fairy Scene_Equip missing'
et=text(equip)
abort 'Fairy equip dispose lifecycle missing' unless et.include?('SLFAIRY_EQUIP_DISPOSE') && et.match?(/def dispose/)
abort 'Fairy equip blocking loop remains' if et.match?(/loop do.*?Graphics\.update.*?Input\.update.*?update.*?\$scene != self/m)

ms=entry(a,'Multi-slot script : Windows') or abort 'Fairy multislot Windows missing'
mt=text(ms)
abort 'Fairy multislot unsafe dispose alias' if mt.match?(/^\s*alias g7_ms_scene_equip_dispose dispose\s*$/)
abort 'Fairy multislot guarded dispose alias missing' unless mt.include?('alias g7_ms_scene_equip_dispose dispose unless method_defined?(:g7_ms_scene_equip_dispose)')

ids=entry(a,'아이디 설정') or abort 'Fairy ID setting missing'
it=text(ids)
abort 'Fairy self-inheriting Sprite_Character remains' if it.match?(/class\s+Sprite_Character\s*<\s*Sprite_Character/)
abort 'Fairy safe Sprite_Character alias missing' unless it.include?('alias sl_id_original_update update')
ido=entry(a,'아이디 출력') or abort 'Fairy ID output missing'
iot=text(ido)
abort 'Fairy self-inheriting Game_Event remains' if iot.match?(/class\s+Game_Event\s*<\s*Game_Event/)
abort 'Fairy self-inheriting Game_Player remains' if iot.match?(/class\s+Game_Player\s*<\s*Game_Player/)
abort 'Fairy safe event/player aliases missing' unless iot.include?('sl_id_original_event_refresh') && iot.include?('sl_id_original_player_refresh')

puts 'FAIRY_SCRIPT_VERIFY_OK'
