# encoding: UTF-8
require 'zlib'

path=ARGV.fetch(0)
a=Marshal.load(File.binread(path))
bad=[]
a.each_with_index do |e,i|
  next unless e.is_a?(Array) && e.length>=3
  begin
    t=Zlib::Inflate.inflate(e[2]).force_encoding(Encoding::UTF_8)
    RubyVM::InstructionSequence.compile(t,e[1].to_s)
  rescue Exception=>x
    bad << [i,e[1].to_s,x.class.to_s,x.message.lines.first.to_s.strip]
  end
end
abort "RGSS_SYNTAX_ERRORS #{bad.inspect}" unless bad.empty?
puts "RGSS_ALL_SCRIPTS_SYNTAX_OK count=#{a.size}"
