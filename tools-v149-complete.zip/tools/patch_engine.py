from pathlib import Path

def repl(path, old, new, count=1):
    p=Path(path); s=p.read_text(); n=s.count(old)
    if n!=count: raise SystemExit(f'{path}: expected {count} copies, found {n}: {old!r}')
    p.write_text(s.replace(old,new,count))

repl('engine/src/config.cpp','fixedFramerate = 40;','fixedFramerate = 0;')
repl('engine/src/config.cpp','defScreenW = 640;','defScreenW = 800;')
repl('engine/src/config.cpp','defScreenH = 480;','defScreenH = 600;')
repl('engine/src/config.cpp','frameSkip = true;','frameSkip = false;')
repl('engine/src/config.cpp','PO_DESC(smoothScaling, bool, true)','PO_DESC(smoothScaling, bool, false)')
repl('engine/src/graphics.cpp','width = clamp(width, 1, 640);\n\theight = clamp(height, 1, 480);','width = clamp(width, 1, 800);\n\theight = clamp(height, 1, 600);')

p=Path('engine/binding-mruby/graphics-binding.cpp'); s=p.read_text()
marker='''MRB_FUNCTION(graphicsFrameReset)\n{\n\tMRB_FUN_UNUSED_PARAM;\n\n\tshState->graphics().frameReset();\n\n\treturn mrb_nil_value();\n}\n'''
add=marker+'''\nMRB_FUNCTION(graphicsResizeScreen)\n{\n\tMRB_FUN_UNUSED_PARAM;\n\tmrb_int width, height;\n\tmrb_get_args(mrb, "ii", &width, &height);\n\tGUARD_EXC( shState->graphics().resizeScreen(width, height); )\n\treturn mrb_nil_value();\n}\n'''
if s.count(marker)!=1: raise SystemExit('graphicsFrameReset marker mismatch')
s=s.replace(marker,add,1)
reg='\tmrb_define_module_function(mrb, module, "frame_reset", graphicsFrameReset, MRB_ARGS_NONE());'
if s.count(reg)!=1: raise SystemExit('frame_reset registration mismatch')
s=s.replace(reg,reg+'\n\tmrb_define_module_function(mrb, module, "resize_screen", graphicsResizeScreen, MRB_ARGS_REQ(2));',1)
p.write_text(s)

repl('engine/binding-mruby/binding-mruby.cpp','\tif (jsSkipFrame() == 1) return;','\t/* V14: Graphics.frame_rate is the only frame limiter. */')

p=Path('engine/binding-mruby/binding-mruby.cpp'); bs=p.read_text()
old_loader='\t\t/* Execute code */\n\t\tmrb_load_nstring_cxt(mrb, decodeBuffer.c_str(), bufferLen, ctx);\n\n\t\tmrb_gc_arena_restore(mrb, ai);\n\n\t\tif (mrb->exc) {\n\t\t\tprintf("%s - err\\n", ctx->filename);\n\t\t\treturn;\n\t\t}'
new_loader='\t\t/* Execute code */\n\t\tprintf("SLSCRIPT|%d|%s\\n", i, RSTRING_PTR(scriptName));\n\t\tfflush(stdout);\n\t\tmrb_load_nstring_cxt(mrb, decodeBuffer.c_str(), bufferLen, ctx);\n\n\t\tmrb_gc_arena_restore(mrb, ai);\n\n\t\tif (mrb->exc) {\n\t\t\tmrb_value exc = mrb_obj_value(mrb->exc);\n\t\t\tmrb_value mesg = mrb_funcall(mrb, exc, "message", 0);\n\t\t\tconst char *excClass = mrb_class_name(mrb, mrb_class(mrb, exc));\n\t\t\tconst char *msg = mrbValueString(mesg);\n\t\t\tprintf("SLSCRIPTERR|%d|%s|%s|%s\\n", i, RSTRING_PTR(scriptName), excClass ? excClass : "?", msg ? msg : "?");\n\t\t\tfflush(stdout);\n\t\t\treturn;\n\t\t}'
if bs.count(old_loader)!=1: raise SystemExit('RGSS loader diagnostic marker mismatch')
p.write_text(bs.replace(old_loader,new_loader,1))

repl('engine/src/emscripten.cpp',"EM_JS(int, file_is_cached, (const char* fullPathC), {\n\tconst fullPath = UTF8ToString(fullPathC);\n\tconst mappingKey = getMappingKey(fullPath);\n\treturn window.fileAsyncCache.hasOwnProperty(mappingKey) ? 1 : 0;\n});","EM_JS(int, file_is_cached, (const char* fullPathC), {\n\tconst fullPath = UTF8ToString(fullPathC);\n\tconst mappingKey = getMappingKey(fullPath);\n\tif (window.fileAsyncCache.hasOwnProperty(mappingKey)) return 1;\n\ttry {\n\t\tconst mv = window.mapping && window.mapping[mappingKey];\n\t\tif (mv) { const fp = '/game/' + mv.split('?')[0]; if (FS.analyzePath(fp).exists && FS.stat(fp).size > 1) { window.fileAsyncCache[mappingKey] = 1; return 1; } }\n\t} catch(e) {}\n\treturn 0;\n});")



# Diagnostic only: make C++ exceptions readable instead of raw numeric JS throws.
repl('engine/CMakeLists.txt','-s DISABLE_EXCEPTION_CATCHING=1','-s DISABLE_EXCEPTION_CATCHING=0')
repl('engine/CMakeLists.txt','-s ASSERTIONS=0','-s ASSERTIONS=2')

# The standalone Emscripten file_packager output used by build_all.sh calls
# Module.FS_createPath / Module.FS_createDataFile and run-dependency helpers.
# Export them explicitly from mkxp.js and keep the filesystem runtime linked in.
p=Path('engine/CMakeLists.txt'); s=p.read_text()
old = "-s EXPORTED_RUNTIME_METHODS='[\\\"ccall\\\",\\\"cwrap\\\"]'"
new = "-s FORCE_FILESYSTEM=1 -s EXPORTED_RUNTIME_METHODS='[\\\"ccall\\\",\\\"cwrap\\\",\\\"FS_createPath\\\",\\\"FS_createDataFile\\\",\\\"addRunDependency\\\",\\\"removeRunDependency\\\"]'"
if s.count(old)!=1: raise SystemExit('Emscripten runtime export marker mismatch')
p.write_text(s.replace(old,new,1))

repl('engine/build.sh','./emsdk install latest','./emsdk install 3.1.37')
repl('engine/build.sh','./emsdk activate latest','./emsdk activate 3.1.37')

p=Path('engine/extra/build_config.rb'); s=p.read_text()
gem="    conf.gem :github => 'pulsejet/mruby-marshal'"
pin="    conf.gem :github => 'mattn/mruby-onig-regexp', :checksum_hash => '25b152264cd4dfac84aa39e5fbb428ec84b95e6a'\n"+gem
if s.count(gem)!=1: raise SystemExit('mruby-marshal build_config marker mismatch')
p.write_text(s.replace(gem,pin,1))

# Visible boot diagnostics. These only print stage markers; they do not alter game logic.
p=Path('engine/src/main.cpp'); ms=p.read_text()
inc='#include <string>'
if ms.count(inc)!=1: raise SystemExit('main.cpp include marker mismatch')
ms=ms.replace(inc,inc+'\n#include <stdio.h>',1)
icon='#include "icon.png.xxd"'
helper='''#include "icon.png.xxd"

static void slBootStage(const char *stage)
{
	printf("SLBOOT|%s\\n", stage);
	fflush(stdout);
}
'''
if ms.count(icon)!=1: raise SystemExit('main.cpp icon marker mismatch')
ms=ms.replace(icon,helper,1)
rg='int rgssThreadFun(void *userdata)\n{\n\tRGSSThreadData *threadData'
if ms.count(rg)!=1: raise SystemExit('rgssThreadFun marker mismatch')
ms=ms.replace(rg,'int rgssThreadFun(void *userdata)\n{\n\tslBootStage("RGSS THREAD");\n\tRGSSThreadData *threadData',1)
main='''#endif
{
	SDL_SetHint(SDL_HINT_VIDEO_MINIMIZE_ON_FOCUS_LOSS, "0");'''
if ms.count(main)!=1: raise SystemExit('main start marker mismatch')
ms=ms.replace(main,'''#endif
{
	slBootStage("ENGINE MAIN");
	SDL_SetHint(SDL_HINT_VIDEO_MINIMIZE_ON_FOCUS_LOSS, "0");''',1)
window='''	/* OSX and Windows have their own native ways of
	 * dealing with icons; don't interfere with them */'''
if ms.count(window)!=1: raise SystemExit('window ready marker mismatch')
ms=ms.replace(window,'	slBootStage("ENGINE WINDOW");\n\n'+window,1)
shared='	bool vsync = conf.vsync || conf.syncToRefreshrate;'
if ms.count(shared)!=1: raise SystemExit('shared state marker mismatch')
ms=ms.replace(shared,'	slBootStage("SHARED STATE READY");\n\n'+shared,1)
execm='''	/* Start script execution */
	scriptBinding->execute();'''
if ms.count(execm)!=1: raise SystemExit('script execute marker mismatch')
ms=ms.replace(execm,'''	/* Start script execution */
	slBootStage("RGSS EXECUTE");
	scriptBinding->execute();''',1)
p.write_text(ms)

print('ENGINE_PATCH_OK')
