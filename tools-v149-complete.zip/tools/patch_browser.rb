# encoding: UTF-8
path, core_js, namespace, title = ARGV
abort 'usage: patch_browser.rb INDEX CORE_JS NAMESPACE TITLE' unless title
html = File.read(path)
cache = 'v15'

bridge = <<'JS'
<script>
(function(){
  var ch={BGM:new Audio(),BGS:new Audio()},pending=[];
  ch.BGM.loop=true;ch.BGS.loop=true;
  function urlFor(n){
    var p=String(n||'').split(String.fromCharCode(92)).join('/')
      .replace(/\.(ogg|mp3|wav|wma|aac|m4a|flac|mid|midi)$/i,'');
    return encodeURI('gameasync/'+p+'.ogg?v=v15');
  }
  function safe(a){
    if(!a||!a.src)return;
    try{
      var p=a.play();
      if(p&&p.catch)p.catch(function(){if(pending.indexOf(a)<0)pending.push(a);});
    }catch(e){if(pending.indexOf(a)<0)pending.push(a);}
  }
  function retry(){var x=pending.slice();pending.length=0;x.forEach(safe);}
  ['touchstart','pointerdown','keydown','mousedown'].forEach(function(n){
    window.addEventListener(n,retry,{passive:true});
  });
  function stop(k){var a=ch[k];if(!a)return;a.pause();try{a.currentTime=0;}catch(e){}}
  function play(k,n,v,p){
    var a=ch[k];if(!a||!n)return;
    var u=urlFor(n);
    if(a.getAttribute('data-sl-src')!==u){
      a.pause();a.src=u;a.setAttribute('data-sl-src',u);a.load();
    }
    var gain=k==='BGS'?0.20:1;
    a.volume=Math.max(0,Math.min(1,Number(v||100)/100*gain));
    a.playbackRate=Math.max(.5,Math.min(1.5,Number(p||100)/100));
    safe(a);
  }
  function err(t){
    var p=document.getElementById('slerr');
    if(!p){
      p=document.createElement('pre');
      p.id='slerr';
      p.style='position:fixed;left:8px;top:8px;right:8px;max-height:70vh;overflow:auto;z-index:999999;background:#000;color:#fff;border:2px solid #d33;padding:10px;font:14px monospace;white-space:pre-wrap';
      document.body.appendChild(p);
    }
    p.textContent=String(t);
  }
  function marker(t){
    var ai=t.indexOf('SLAUDIO|');
    if(ai>=0){
      var p=t.slice(ai).split('|'),cmd=p[1]||'',k=cmd.split('_')[0];
      if(/_PLAY$/.test(cmd))play(k,p.slice(2,-2).join('|'),p[p.length-2],p[p.length-1]);
      else if(/_STOP$/.test(cmd))stop(k);
      else if(/_FADE$/.test(cmd))setTimeout(function(){stop(k);},Number(p[2])||0);
    }
    var qi=t.indexOf('SLQS|');
    if(qi>=0){
      var q=t.slice(qi).split('|');
      if(window.slSetQuickLabel&&q.length>=3)window.slSetQuickLabel(q[1],q.slice(2).join('|'));
    }
    if(/SLRUNTIMEERR|SLSCRIPTERR/.test(t))err(t);
  }
  var log=console.log.bind(console);
  console.log=function(){
    var a=[].slice.call(arguments),t=a.join(' ');
    try{marker(t);}catch(e){log('SLMARKERERR|'+e);}
    log.apply(console,a);
  };
  window.addEventListener('error',function(e){err('JS ERROR | '+e.message);});
  window.addEventListener('unhandledrejection',function(e){err('PROMISE ERROR | '+String(e.reason));});
  window.slAudioBridge=ch;
})();
</script>
JS

html.sub!('<head>', "<head>\n#{bridge}") or abort 'head target missing'

html.sub!('<script src="js/drive.js"></script>', '<script src="js/drive.js?v=v15"></script>') or abort 'drive include missing'
html.sub!('<script src="js/dpad.js"></script>', '<script src="js/dpad.js?v=v15"></script>') or abort 'dpad include missing'
html.sub!('<script src="gameasync/mapping.js"></script>', '<script src="gameasync/mapping.js?v=v15"></script>') or abort 'mapping include missing'

html.sub!('preRun: [createDummies],', 'preRun: [function(){window.restoreLocalFilesBeforeRun();}],') or abort 'preRun missing'
html.sub!('postRun: [loadFiles, preloadInit],', 'postRun: [],') or abort 'postRun missing'

html.sub!(/var namespace = '[^']*';/, "var namespace = '#{namespace}';") or abort 'namespace missing'
html.sub!(/var wTitle = '[^']*'/, "var wTitle = '#{title}'") or abort 'title var missing'
html.sub!('<title>MKXP</title>', "<title>#{title}</title>") if html.include?('<title>MKXP</title>')

html.sub!('width="640" height="480"', 'width="800" height="600"') or abort 'canvas size missing'

html.sub!("getLazyAsset('mkxp.wasm', 'Game engine'", "getLazyAsset('mkxp.wasm?v=v15', 'Game engine'") or abort 'wasm loader missing'
html.sub!("s.setAttribute('src', 'mkxp.js');", "s.setAttribute('src', 'mkxp.js?v=v15');") or abort 'mkxp js loader missing'

bitmap_rx=/\s*getLazyAsset\('gameasync\/bitmap-map\.js',\s*'Primary assets',\s*\(\)\s*=>\s*\{\s*const s = document\.createElement\('script'\);\s*s\.setAttribute\('src',\s*'gameasync\/bitmap-map\.js'\);\s*document\.body\.appendChild\(s\);\s*\}\);/m
abort 'bitmap-map loader missing' unless html.match?(bitmap_rx)
html.sub!(bitmap_rx,'')

# Keep progress useful while data downloads, then hide it once runtime starts.
html.sub!('setStatus: function(text) {}', <<'JS'.chomp) or abort 'setStatus marker missing'
setStatus: function(text) {
                var p=document.getElementById('progress');
                if(p && text) p.textContent=String(text);
                if(text==='Running...'){
                    var sp=document.getElementById('spinner');
                    if(sp)sp.style.display='none';
                    setTimeout(function(){if(p)p.style.display='none';},700);
                }
            }
JS

css = <<'CSS'
<style id="sl-mobile-v15-style">
#dpad,#apad{display:none!important}
#sl-mobile-ui{
  position:fixed;inset:0;z-index:5000;pointer-events:none;
  touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none
}
#sl-joystick{
  position:absolute;left:max(14px,env(safe-area-inset-left));
  bottom:max(18px,env(safe-area-inset-bottom));
  width:178px;height:178px;border-radius:50%;pointer-events:auto;touch-action:none
}
#sl-joy-base{
  position:absolute;inset:19px;border-radius:50%;
  border:2px solid rgba(255,255,255,.34);background:rgba(0,0,0,.20);
  box-shadow:inset 0 0 22px rgba(0,0,0,.25)
}
#sl-joy-knob{
  position:absolute;left:54px;top:54px;width:70px;height:70px;border-radius:50%;
  border:2px solid rgba(255,255,255,.66);background:rgba(35,35,35,.64);
  box-shadow:0 3px 14px rgba(0,0,0,.45);transform:translate(0,0)
}
#sl-actions{
  position:absolute;right:max(14px,env(safe-area-inset-right));
  bottom:max(18px,env(safe-area-inset-bottom));
  display:flex;flex-direction:column;align-items:flex-end;gap:8px;pointer-events:none
}
.sl-row{display:flex;gap:8px;justify-content:flex-end;align-items:center;pointer-events:none}
.sl-btn{
  box-sizing:border-box;border-radius:50%;border:2px solid rgba(255,255,255,.48);
  background:rgba(0,0,0,.42);color:#fff;font:600 12px system-ui,sans-serif;
  pointer-events:auto;touch-action:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis
}
.sl-btn.active{transform:scale(.93);background:rgba(255,255,255,.22);border-color:rgba(255,255,255,.9)}
.sl-quick{width:54px;height:54px;font-size:10px;padding:2px}
#sl-config{width:46px;height:46px;font-size:18px}
#sl-equip,#sl-bag{width:56px;height:56px}
#sl-cancel{width:64px;height:64px}
#sl-confirm{width:82px;height:82px;font-size:15px}
#progress{max-width:80vw;z-index:9000;font:12px system-ui,sans-serif}
@media(orientation:portrait){
  #sl-joystick{width:154px;height:154px}
  #sl-joy-base{inset:17px}
  #sl-joy-knob{left:47px;top:47px;width:60px;height:60px}
  #sl-actions{transform:scale(.82);transform-origin:right bottom}
}
</style>
CSS
html.sub!('</head>', css+"\n</head>") or abort 'head close missing'

controls = <<'HTML'
<div id="sl-mobile-ui">
  <div id="sl-joystick">
    <div id="sl-joy-base"></div>
    <div id="sl-joy-knob"></div>
  </div>
  <div id="sl-actions">
    <div class="sl-row">
      <button id="sl-q1" class="sl-btn sl-quick">1</button>
      <button id="sl-q2" class="sl-btn sl-quick">2</button>
      <button id="sl-q3" class="sl-btn sl-quick">3</button>
      <button id="sl-q4" class="sl-btn sl-quick">4</button>
    </div>
    <div class="sl-row">
      <button id="sl-config" class="sl-btn">⚙</button>
      <button id="sl-equip" class="sl-btn">장비</button>
      <button id="sl-bag" class="sl-btn">가방</button>
    </div>
    <div class="sl-row">
      <button id="sl-cancel" class="sl-btn">취소</button>
      <button id="sl-confirm" class="sl-btn">확인</button>
    </div>
  </div>
</div>
<script>
window.addEventListener('load',function(){
  if(window.initSLMobileControls)window.initSLMobileControls();
});
</script>
HTML

core_tag = %Q{<script src="#{core_js}?v=v15"></script>}
if html.include?('<!-- <script async type="text/javascript" src="mkxp.js"></script> -->')
  html.sub!('<!-- <script async type="text/javascript" src="mkxp.js"></script> -->', core_tag)
elsif html.include?('<!-- {{{ SCRIPT }}} -->')
  html.sub!('<!-- {{{ SCRIPT }}} -->', core_tag)
else
  abort 'core package injection marker missing'
end

html.sub!('</body>', "#{controls}\n</body>") or abort 'body close missing'

File.write(path,html)
puts "BROWSER_V15_OK #{title}"
